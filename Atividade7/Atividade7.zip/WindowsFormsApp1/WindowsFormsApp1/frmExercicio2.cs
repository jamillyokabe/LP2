﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtNumeroN_Validated(object sender, EventArgs e)
        {
            double numN, numH = 0;

            if (!Double.TryParse(txtNumeroN.Text, out numN) || numN == 0)
            {
                MessageBox.Show("Número inválido!");
            }
            else
                for (double i = 1; i <= numN; i++)
                {
                    numH += 1 / i;
                }
            txtNumeroH.Text = numH.ToString();
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumeroH.Clear();
            txtNumeroN.Clear();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {

        }
    }
}
