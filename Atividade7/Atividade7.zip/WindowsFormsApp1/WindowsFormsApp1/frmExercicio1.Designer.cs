﻿namespace WindowsFormsApp1
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtEx1 = new System.Windows.Forms.RichTextBox();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnLetra = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtEx1
            // 
            this.rchtxtEx1.Location = new System.Drawing.Point(152, 70);
            this.rchtxtEx1.Margin = new System.Windows.Forms.Padding(4);
            this.rchtxtEx1.MaxLength = 100;
            this.rchtxtEx1.Name = "rchtxtEx1";
            this.rchtxtEx1.Size = new System.Drawing.Size(768, 160);
            this.rchtxtEx1.TabIndex = 0;
            this.rchtxtEx1.Text = "";
            // 
            // btnBranco
            // 
            this.btnBranco.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranco.Location = new System.Drawing.Point(152, 303);
            this.btnBranco.Margin = new System.Windows.Forms.Padding(4);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(213, 101);
            this.btnBranco.TabIndex = 1;
            this.btnBranco.Text = "Número de espaços em branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnLetra
            // 
            this.btnLetra.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetra.Location = new System.Drawing.Point(439, 303);
            this.btnLetra.Margin = new System.Windows.Forms.Padding(4);
            this.btnLetra.Name = "btnLetra";
            this.btnLetra.Size = new System.Drawing.Size(204, 101);
            this.btnLetra.TabIndex = 2;
            this.btnLetra.Text = "Vezes em que aparece a letra R";
            this.btnLetra.UseVisualStyleBackColor = true;
            this.btnLetra.Click += new System.EventHandler(this.btnLetra_Click);
            // 
            // btnPar
            // 
            this.btnPar.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPar.Location = new System.Drawing.Point(717, 303);
            this.btnPar.Margin = new System.Windows.Forms.Padding(4);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(204, 101);
            this.btnPar.TabIndex = 3;
            this.btnPar.Text = "Vezes em que ocorre par de letras";
            this.btnPar.UseVisualStyleBackColor = true;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(439, 442);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(4);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(204, 50);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnLetra);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.rchtxtEx1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtEx1;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnLetra;
        private System.Windows.Forms.Button btnPar;
        private System.Windows.Forms.Button btnLimpar;
    }
}