﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int espaco;
       
            espaco = 0;

            for (int i = 0; i < rchtxtEx1.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtEx1.Text[i]))
                    espaco++;
            }

           MessageBox.Show($"Existe(m) {espaco} espaço(s) em branco na frase.");

        }

        private void btnLetra_Click(object sender, EventArgs e)
        {
            int letraR;

            letraR = 0;

            for (int i = 0; i < rchtxtEx1.Text.Length; i++)
            {
                if (rchtxtEx1.Text[i] == 'R' || rchtxtEx1.Text[i] == 'r')
                    letraR++;
            }
            MessageBox.Show($"Existe(m) {letraR} letras R na frase.");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int parLetras;

            parLetras = 0;

            for (int i = 0; i < rchtxtEx1.Text.Length - 1; i++)
            {
                if (rchtxtEx1.Text[i] == rchtxtEx1.Text[i + 1])
                {
                    parLetras++;
                }
            }
            MessageBox.Show($"Existe(m) {parLetras} par(es) de letras na frase.");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchtxtEx1.Clear();
        }
    }
}
