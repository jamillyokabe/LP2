﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

private void btnTestar_Click(object sender, EventArgs e)
        {
            {
                string texto;

                texto = txtPalindromo.Text.ToLower();
                texto = texto.Replace(" ", "");

                char[] vreverse = texto.ToCharArray();
                Array.Reverse(vreverse);

                string reverso = new string(vreverse);

                if (texto == reverso)
                {
                    MessageBox.Show("É palíndromo!");
                }
                else
                {
                    MessageBox.Show("Não é palíndromo");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPalindromo.Clear();
        }
    }
}

