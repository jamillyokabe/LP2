﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        
        

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtMatricula.Clear();
            txtProducao.Clear();
            txtSalario.Clear();
            txtGratificacao.Clear();
            txtBruto.Clear();
           
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            {
                float salario, salarioBruto, gratificacao;
                int producao, B, C, D;

                B = C = D = 0;

                if (!float.TryParse(txtSalario.Text, out salario))
                {
                    MessageBox.Show("Valor inválido!");
                    txtSalario.Focus();
                    return;
                }
                if (!float.TryParse(txtGratificacao.Text, out gratificacao))
                {
                    MessageBox.Show("Valor inválido!");
                    txtGratificacao.Focus();
                    return;
                }
                if (!int.TryParse(txtProducao.Text, out producao))
                {
                    MessageBox.Show("Valor inválido!");
                    txtProducao.Focus();
                    return;
                }

                if (salario <= 7000.00)
                {
                    if (producao >= 150)
                        D = 1;
                    if (producao >= 120)
                        C = 1;
                    if (producao >= 100)
                        B = 1;


                    salarioBruto = (float)(salario + (salario * ((0.05 * B) + (0.1 * C) + (0.1 * D)))) + gratificacao;
                }
                else if (producao >= 150 && gratificacao > 0)
                {
                    B = C = D = 1;
                    salarioBruto = (float)(salario + (salario * ((0.05 * B) + (0.1 * C) + (0.1 * D)))) + gratificacao;
                }
                else
                {
                    salarioBruto = salario;
                }

                txtBruto.Text = salarioBruto.ToString("F2");
            }
        }
    }
}
