﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciar1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtEntrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);

            MessageBox.Show("Nome: " + objMensalista.NomeEmpregado + "\n" +
                "Matrícula: " + objMensalista.Matricula + "\n" + "Tempo de trabalho: " +
                objMensalista.TempoTrabalho() + " dias" + "\n" + "Salário Final: R$" + objMensalista.SalarioBruto().ToString("N2"));

            //static
            //MessageBox.Show(Mensalista.Empresa);

            //ou usando interpolação
            MessageBox.Show($"Empresa: {Mensalista.Empresa}");
        }

        private void btnInstanciar2_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista(Convert.ToInt32(txtMatricula.Text), txtNome.Text,
                Convert.ToDateTime(txtEntrada.Text), Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Nome: " + ObjMensalista.NomeEmpregado + "\n" +
                "Matrícula: " + ObjMensalista.Matricula + "\n" + "Tempo de trabalho: " +
                ObjMensalista.TempoTrabalho() + " dias" + "\n" + "Salário Final: R$" + ObjMensalista.SalarioBruto().ToString("N2"));
        }
    }
}
