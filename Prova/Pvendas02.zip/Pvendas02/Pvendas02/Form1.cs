﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[2, 4];
            string auxiliar = "";
            double totalSemana, totalMes, totalGeral;
            double[] vendasMes = new double[2];
            double[] vendasSemana = new double[4];

            totalSemana = 0;
            totalMes = 0;
            totalGeral = 0;


            for (int mes = 0; mes < 2; mes++)
                for (int semana = 0; semana < 4; semana++)
                {
                    string prompt = $"Inserir valor de vendas do mês {mes + 1} da {semana + 1}ª semana";
                    auxiliar = Interaction.InputBox(prompt, "Entrada de dados");

                    if (auxiliar == "")
                    {
                        break;
                    }

                    if (!Double.TryParse(auxiliar, out vendas[mes, semana]) && (vendas[mes, semana] < 0))
                    {
                        MessageBox.Show("Valor inválido!");
                        semana--;
                    }
                    else
                    {
                        vendas[mes, semana] = Double.Parse(auxiliar);
                    }


                    vendasSemana[semana] += vendas[mes, semana];
                    vendasMes[mes] += vendas[mes, semana];

                    totalGeral += vendas[mes, semana];


                }
            for (int mes = 0; mes < 2; mes++)
                for (int semana = 0; semana < 4; semana++)
                {
                    lstbxVendas.Items.Add($"Total do mês {mes + 1} da Semana {semana + 1}: {vendasSemana[semana]}\n");
                    lstbxVendas.Items.Add($">> Total Mês {mes + 1}: {vendasMes[mes]}\n");
                }
                               
           
                      lstbxVendas.Items.Add($">> Total Geral: {totalGeral}\n");
                


                
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}
