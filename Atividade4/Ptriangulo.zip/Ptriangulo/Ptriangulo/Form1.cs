﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        string tipo;

        private void txtLadoB_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB) || ladoB == 0)
            {
                MessageBox.Show("Valor inválido!");
                txtLadoB.Focus();
            } 
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC) || ladoC == 0)
            {
                MessageBox.Show("Valor inválido!");
                txtLadoC.Focus();
            }
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            {
                if ((Math.Abs(ladoB - ladoC) < ladoA && ladoA < ladoB + ladoC) ||
                    (Math.Abs(ladoA - ladoC) < ladoB && ladoB < ladoA + ladoC) ||
                    (Math.Abs(ladoA - ladoB) < ladoC && ladoC < ladoA + ladoB))
                {
                   
                    if (ladoA == ladoB && ladoB == ladoC)
                        tipo = "equilátero!";
                    else
                    if (ladoA != ladoB && ladoB != ladoC && ladoA != ladoC)
                        tipo = "escaleno!";
                    else
                        tipo = "isósceles!";
                    txtResultado.Text = ("É um triângulo " + tipo);
                }
                else
                { 
                    txtResultado.Text = ("Não é um triângulo!");
                }
            }
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            txtResultado.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
                    {
                        InitializeComponent();
                    }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA) || ladoA ==0) 
            {
                MessageBox.Show("Valor inválido!");
                txtLadoA.Focus();
            }
        }
    }
}
